/**
 * @license Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.plugins.setLang( 'uploadwidget', 'uk', {
	abort: 'Завантаження перервано користувачем.',
	doneOne: 'Файл цілком завантажено.',
	doneMany: 'Цілком завантажено %1 файлів.',
	uploadOne: 'Завантаження файлу ({percentage}%)...',
	uploadMany: 'Завантажено {current} із {max} файлів завершено на ({percentage}%)...'
} );
