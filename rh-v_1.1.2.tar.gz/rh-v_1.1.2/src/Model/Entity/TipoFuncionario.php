<?php

namespace App\Model\Entity;

use Cake\ORM\Entity;

class TipoFuncionario extends Entity
{
    
}