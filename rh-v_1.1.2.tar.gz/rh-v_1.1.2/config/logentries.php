<?php

return [
    'LogEntries' => [
        'persistent' => true,
        'severity' => LOG_DEBUG,
        'ssl' => false,
        'localTimestamp' => true,
        'client' => [
            'token' => '810c20c7-ad63-485b-a8b6-a7d7e5d5c4ed'
        ],
        'dataHub' => [
            'IPAddress' => '',
            'port' => 10000,
            'enabled' => false
        ],
        'host' => [
            'name' => '',
            'id' => '',
            'enabled' => false
        ]
    ]
];